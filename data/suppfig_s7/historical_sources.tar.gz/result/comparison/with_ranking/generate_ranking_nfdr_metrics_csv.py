#!/usr/bin/env python3
"""
Generate NFDR Metrics CSV for Baseline (control) and Raw Memory (experimental)
================================================================================

Parses run_log files from with_ranking experiment directories to extract
per-module, per-iteration, per-category NFDR data for BOTH conditions.

Output: ranking_nfdr_metrics.csv
Columns: disease, module, iteration, category, retained, newgen, matched, new_matched, fdr_pct, nfdr_pct, condition

Usage:
    python generate_ranking_nfdr_metrics_csv.py
"""

import os
import re
import glob
import pandas as pd

# ============================================================================
# Configuration
# ============================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_CSV = os.path.join(SCRIPT_DIR, "ranking_nfdr_metrics.csv")

DISEASE_CODES = ["CARDI", "HF", "INSUL", "MELAN", "OBESI"]

# Two conditions to extract
CONDITIONS = {
    'control': 'Baseline (No Memory)',
    'experimental': 'Raw Memory Bank',
}


def find_run_log(disease_dir, tag):
    """Find the run_log file for a given condition tag within the disease directory."""
    pattern = os.path.join(disease_dir, f"*_{tag}", "run_log_*.txt")
    matches = glob.glob(pattern)
    if not matches:
        return None
    return max(matches, key=os.path.getmtime)


def extract_category_data_from_log(log_path, disease_code, condition):
    """
    Extract per-module per-iteration per-category NFDR data from a run_log file.

    Iteration 1 format (7 columns):
      Category   | Retained | NewGen | Total | Match | Mat%  | FDR  | FDR%

    Iteration 2+ format (11 columns):
      Category   | Retained | NewGen | Total | Match | NewMat | Mat%  | NMat%  | FDR  | NewFDR | FDR%  | NFDR%
    """
    if not os.path.exists(log_path):
        print(f"  ⚠️  File not found: {log_path}")
        return []

    with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    records = []

    pattern_7col = re.compile(
        r'^\s*(GO:BP|GO:MF|GO:CC|KEGG|REAC)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*$'
    )

    pattern_11col = re.compile(
        r'^\s*(GO:BP|GO:MF|GO:CC|KEGG|REAC)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)%'
    )

    lines = content.split('\n')
    current_module = None
    current_iteration = 1

    for line in lines:
        module_match = re.search(r'MODULE\s+(\d+)\s*\(\d+/\d+\)', line)
        if module_match:
            current_module = int(module_match.group(1))
            current_iteration = 1

        phase2_module_match = re.search(r'ITERATING MODULE\s+(\d+)', line)
        if phase2_module_match:
            current_module = int(phase2_module_match.group(1))

        iter_match = re.search(r'ITERATION\s+(\d+)/\d+', line, re.IGNORECASE)
        if iter_match:
            current_iteration = int(iter_match.group(1))

        match_11 = pattern_11col.match(line.strip())
        if match_11 and current_module is not None:
            records.append({
                'disease': disease_code,
                'module': current_module,
                'iteration': current_iteration,
                'category': match_11.group(1),
                'retained': int(match_11.group(2)),
                'newgen': int(match_11.group(3)),
                'matched': int(match_11.group(5)),
                'new_matched': int(match_11.group(6)),
                'fdr_pct': int(match_11.group(11)),
                'nfdr_pct': int(match_11.group(12)),
                'condition': condition,
            })
            continue

        match_7 = pattern_7col.match(line.strip())
        if match_7 and current_module is not None and current_iteration == 1:
            fdr_pct = int(match_7.group(8))
            matched = int(match_7.group(5))
            records.append({
                'disease': disease_code,
                'module': current_module,
                'iteration': current_iteration,
                'category': match_7.group(1),
                'retained': int(match_7.group(2)),
                'newgen': int(match_7.group(3)),
                'matched': matched,
                'new_matched': matched,  # Iter 1: all matched are new
                'fdr_pct': fdr_pct,
                'nfdr_pct': fdr_pct,  # Iter 1: FDR% = NFDR%
                'condition': condition,
            })

    return records


def main():
    print("=" * 70)
    print("Generate Baseline & Raw Memory NFDR Metrics CSV")
    print("=" * 70)

    all_records = []

    for disease in DISEASE_CODES:
        disease_dir = os.path.join(SCRIPT_DIR, f"iterative_feedback_{disease}")
        if not os.path.exists(disease_dir):
            # Try comparison_ prefix for new diseases
            disease_dir = os.path.join(SCRIPT_DIR, f"iterative_feedback_comparison_{disease}")
            if not os.path.exists(disease_dir):
                print(f"  ⚠️  {disease}: Directory not found, skipping")
                continue

        for cond_tag, cond_label in CONDITIONS.items():
            log_path = find_run_log(disease_dir, cond_tag)
            if log_path is None:
                print(f"  ⚠️  {disease} [{cond_tag}]: No run_log found, skipping")
                continue

            print(f"  {disease} [{cond_tag}]: {os.path.basename(log_path)}")
            records = extract_category_data_from_log(log_path, disease, cond_tag)
            print(f"    → Extracted {len(records)} records")

            if records:
                df_tmp = pd.DataFrame(records)
                for it in sorted(df_tmp['iteration'].unique()):
                    it_df = df_tmp[df_tmp['iteration'] == it]
                    modules = it_df['module'].nunique()
                    avg_nfdr = it_df['nfdr_pct'].mean()
                    print(f"    Iter {it}: {modules} modules, avg NFDR% = {avg_nfdr:.1f}%")

            all_records.extend(records)

    if not all_records:
        print("\n❌ No data extracted.")
        return

    df = pd.DataFrame(all_records)
    df = df[df['iteration'] <= 2]

    print(f"\nTotal records (Iter 1-2): {len(df)}")
    print(f"Diseases: {sorted(df['disease'].unique())}")
    print(f"Conditions: {sorted(df['condition'].unique())}")
    print(f"Categories: {sorted(df['category'].unique())}")

    df.to_csv(OUTPUT_CSV, index=False)
    print(f"\n✅ Saved: {OUTPUT_CSV}")

    # Summary per condition
    for cond in sorted(df['condition'].unique()):
        cond_df = df[df['condition'] == cond]
        print(f"\n--- {CONDITIONS.get(cond, cond)} ---")
        for disease in sorted(cond_df['disease'].unique()):
            d_df = cond_df[cond_df['disease'] == disease]
            modules = d_df['module'].nunique()
            print(f"  {disease:6s}: {len(d_df):4d} records, {modules:2d} modules")


if __name__ == '__main__':
    main()
