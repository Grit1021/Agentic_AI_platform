#!/usr/bin/env python3
"""
Generate NFDR Metrics CSV for RAG+ with User Prompt Condition (5 diseases)
==========================================================================

Parses run_log files from the with_rag_plus_user_prompt experiment directories
to extract per-module, per-iteration, per-category NFDR data.

Output: rag_plus_prompt_nfdr_metrics.csv
Columns: disease, module, iteration, category, retained, newgen, matched, new_matched, fdr_pct, nfdr_pct

Usage:
    python generate_rag_plus_prompt_nfdr_metrics_csv.py
"""

import os
import re
import glob
import pandas as pd

# ============================================================================
# Configuration
# ============================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_CSV = os.path.join(SCRIPT_DIR, "rag_plus_prompt_nfdr_metrics.csv")

DISEASE_CODES = ["CARDI", "HF", "INSUL", "MELAN", "OBESI"]


def find_run_log(disease_dir):
    """Find the run_log file within the disease directory.
    
    Searches in *_exp3_semantic_plus/ subdirectories for run_log_*.txt.
    Returns the latest one found.
    """
    pattern = os.path.join(disease_dir, "*_exp3_semantic_plus", "run_log_*.txt")
    matches = glob.glob(pattern)
    if not matches:
        pattern = os.path.join(disease_dir, "*_exp3_semantic_rag", "run_log_*.txt")
        matches = glob.glob(pattern)
    if not matches:
        return None
    return max(matches, key=os.path.getmtime)


def extract_category_data_from_log(log_path, disease_code):
    """
    Extract per-module per-iteration per-category NFDR data from a run_log file.

    Iteration 1 format (7 columns):
      Category   | Retained | NewGen | Total | Match | Mat%  | FDR  | FDR%
      GO:BP      | 0        | 10     | 10    | 13    |  130% | 3    |   23%

    Iteration 2+ format (11 columns):
      Category   | Retained | NewGen | Total | Match | NewMat | Mat%  | NMat%  | FDR  | NewFDR | FDR%  | NFDR%
      GO:BP      | 2        | 8      | 10    | 8     | 6      |   80% |   60%  | 6    | 4      |   75% |   67%
    """
    if not os.path.exists(log_path):
        print(f"  ⚠️  File not found: {log_path}")
        return []

    with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    records = []

    # Iteration 1 format (7 columns)
    pattern_7col = re.compile(
        r'^\s*(GO:BP|GO:MF|GO:CC|KEGG|REAC)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*$'
    )

    # Iteration 2+ format (11 columns)
    pattern_11col = re.compile(
        r'^\s*(GO:BP|GO:MF|GO:CC|KEGG|REAC)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)%\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)%\s*\|\s*(\d+)%'
    )

    lines = content.split('\n')
    current_module = None
    current_iteration = 1

    for line in lines:
        # Detect module start - Phase 1
        module_match = re.search(r'MODULE\s+(\d+)\s*\(\d+/\d+\)', line)
        if module_match:
            current_module = int(module_match.group(1))
            current_iteration = 1

        # Detect Phase 2 module start
        phase2_module_match = re.search(r'ITERATING MODULE\s+(\d+)', line)
        if phase2_module_match:
            current_module = int(phase2_module_match.group(1))

        # Detect iteration start (Phase 2)
        iter_match = re.search(r'ITERATION\s+(\d+)/\d+', line, re.IGNORECASE)
        if iter_match:
            current_iteration = int(iter_match.group(1))

        # Try 11-column format (Iteration 2+)
        match_11 = pattern_11col.match(line.strip())
        if match_11 and current_module is not None:
            category = match_11.group(1)
            retained = int(match_11.group(2))
            newgen = int(match_11.group(3))
            matched = int(match_11.group(5))
            new_matched = int(match_11.group(6))
            nfdr_pct = int(match_11.group(12))
            fdr_pct = int(match_11.group(11))

            records.append({
                'disease': disease_code,
                'module': current_module,
                'iteration': current_iteration,
                'category': category,
                'retained': retained,
                'newgen': newgen,
                'matched': matched,
                'new_matched': new_matched,
                'fdr_pct': fdr_pct,
                'nfdr_pct': nfdr_pct
            })
            continue

        # Try 7-column format (Iteration 1)
        match_7 = pattern_7col.match(line.strip())
        if match_7 and current_module is not None and current_iteration == 1:
            category = match_7.group(1)
            retained = int(match_7.group(2))
            newgen = int(match_7.group(3))
            matched = int(match_7.group(5))
            fdr_pct = int(match_7.group(8))

            records.append({
                'disease': disease_code,
                'module': current_module,
                'iteration': current_iteration,
                'category': category,
                'retained': retained,
                'newgen': newgen,
                'matched': matched,
                'new_matched': matched,  # Iter 1: all matched are new
                'fdr_pct': fdr_pct,
                'nfdr_pct': fdr_pct  # Iter 1: FDR% = NFDR%
            })

    return records


def main():
    print("=" * 70)
    print("Generate RAG+ with User Prompt NFDR Metrics CSV (5 diseases)")
    print("=" * 70)

    all_records = []

    for disease in DISEASE_CODES:
        disease_dir = os.path.join(SCRIPT_DIR, f"iterative_feedback_{disease}")
        if not os.path.exists(disease_dir):
            print(f"  ⚠️  {disease}: Directory not found, skipping")
            continue

        log_path = find_run_log(disease_dir)
        if log_path is None:
            print(f"  ⚠️  {disease}: No run_log found, skipping")
            continue

        print(f"  {disease}: {os.path.basename(log_path)}")
        records = extract_category_data_from_log(log_path, disease)
        print(f"    → Extracted {len(records)} records")

        if records:
            df_tmp = pd.DataFrame(records)
            for it in sorted(df_tmp['iteration'].unique()):
                it_df = df_tmp[df_tmp['iteration'] == it]
                modules = it_df['module'].nunique()
                avg_nfdr = it_df['nfdr_pct'].mean()
                print(f"    Iter {it}: {modules} modules, avg NFDR% = {avg_nfdr:.1f}%")

        all_records.extend(records)

    if not all_records:
        print("\n❌ No data extracted. Check run_log format.")
        return

    # Create DataFrame and filter to Iter <= 2
    df = pd.DataFrame(all_records)
    df = df[df['iteration'] <= 2]

    print(f"\nTotal records (Iter 1-2): {len(df)}")
    print(f"Diseases: {sorted(df['disease'].unique())}")
    print(f"Categories: {sorted(df['category'].unique())}")

    # Save CSV
    df.to_csv(OUTPUT_CSV, index=False)
    print(f"\n✅ Saved: {OUTPUT_CSV}")

    # Summary
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    for disease in sorted(df['disease'].unique()):
        d_df = df[df['disease'] == disease]
        modules = d_df['module'].nunique()
        print(f"  {disease:6s}: {len(d_df):4d} records, {modules:2d} modules")
    print("=" * 70)


if __name__ == '__main__':
    main()
