#!/usr/bin/env python3
"""
Memory Bank Evaluation: Per-Category & Per-Iteration Analysis
=============================================================
Generates 4 figures that demonstrate Memory Bank effects broken down
by pathway category (GO:BP, GO:MF, GO:CC, KEGG, REAC) and iteration.

Figure 1: Grouped bar — Mean validated pathway COUNT by Category × Condition, split by Iter1/Iter2
Figure 2: Heatmap — Paired Δ (each Memory condition − Baseline) by Category, split by Iter
Figure 3: Stacked bar — Iter1-retained + Iter2-new composition per Category per Condition
Figure 4: Positive feedback scatter — Iter1 count vs Final total, colored by category
"""

import os, glob, re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from scipy import stats as sp

# ── paths ────────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(BASE, "combined_plots")
os.makedirs(OUT, exist_ok=True)
EXTERNAL_PDF_OUT = os.path.abspath(os.path.join(BASE, '..', 'cross_disease_analysis_external', 'pdf'))
os.makedirs(EXTERNAL_PDF_OUT, exist_ok=True)

DISEASES = ['CARDI', 'HF', 'INSUL', 'MELAN', 'OBESI']
CONDS    = ['Baseline', 'Raw_Memory', 'Semantic_RAG', 'Semantic_RAG+', 'RAG+_Prompt']
CATS     = ['GO:BP', 'GO:MF', 'GO:CC', 'KEGG', 'REAC']

COND_COLORS = {
    'Baseline':      '#78909C',   # grey
    'Raw_Memory':    '#5C6BC0',   # indigo
    'Semantic_RAG':  '#26A69A',   # teal
    'Semantic_RAG+': '#FFA726',   # orange
    'RAG+_Prompt':   '#E53935',   # red
}
COND_LABELS = {
    'Baseline':      'BL',
    'Raw_Memory':    'RM',
    'Semantic_RAG':  'RAG',
    'Semantic_RAG+': 'RAG+',
    'RAG+_Prompt':   'RAG+P',
}
CAT_COLORS = {
    'GO:BP': '#E53935',
    'GO:MF': '#1E88E5',
    'GO:CC': '#43A047',
    'KEGG':  '#FB8C00',
    'REAC':  '#8E24AA',
}

# ── data loading ─────────────────────────────────────────────────────────

def find_cond_dir(disease, ctype, suffix):
    # Try standard name first, then comparison_ prefix
    for prefix in [f'iterative_feedback_{disease}', f'iterative_feedback_comparison_{disease}']:
        pattern = os.path.join(BASE, ctype, prefix,
                               f'{disease}_aggregated_*_{suffix}')
        dirs = sorted(glob.glob(pattern))
        for d in reversed(dirs):
            if os.path.isdir(os.path.join(d, 'phase2_module_iteration')):
                return d
        if dirs:
            return dirs[-1]
    return None

def get_cond_dirs(disease):
    r = {}
    bl  = find_cond_dir(disease, 'with_ranking', 'control')
    rm  = find_cond_dir(disease, 'with_ranking', 'experimental')
    # Try multiple tags for RAG conditions
    rag = find_cond_dir(disease, 'with_rag', 'exp3_semantic_rag')
    if not rag:
        rag = find_cond_dir(disease, 'with_rag', 'exp3_pure_rag')
    ragp = find_cond_dir(disease, 'with_rag_plus', 'exp3_semantic_rag')
    if not ragp:
        ragp = find_cond_dir(disease, 'with_rag_plus', 'exp3_semantic_plus')
    ragp_prompt = find_cond_dir(disease, 'with_rag_plus_user_prompt', 'exp3_semantic_plus')
    if not ragp_prompt:
        ragp_prompt = find_cond_dir(disease, 'with_rag_plus_user_prompt', 'exp3_semantic_rag')
    if bl:          r['Baseline'] = bl
    if rm:          r['Raw_Memory'] = rm
    if rag:         r['Semantic_RAG'] = rag
    if ragp:        r['Semantic_RAG+'] = ragp
    if ragp_prompt: r['RAG+_Prompt'] = ragp_prompt
    return r

def load_all_pathway_data():
    """Load final_aggregated_pathways.csv for all diseases × conditions."""
    rows = []
    for disease in DISEASES:
        cd = get_cond_dirs(disease)
        for cond in CONDS:
            if cond not in cd:
                continue
            fag = os.path.join(cd[cond], 'final_aggregated_pathways.csv')
            if not os.path.exists(fag):
                continue
            df = pd.read_csv(fag)
            if 'source' not in df.columns or 'iteration_source' not in df.columns:
                continue
            for _, row in df.iterrows():
                rows.append({
                    'disease':   disease,
                    'condition': cond,
                    'category':  row['source'],
                    'iteration': int(row['iteration_source']),
                    'module':    row.get('module_id', '?'),
                    'gpt_rank':  row.get('gpt_rank', np.nan),
                })
    return pd.DataFrame(rows)

def load_nfdr_data():
    """Load NFDR metrics for all 4 conditions."""
    frames = []
    # Baseline + Raw Memory
    bl_path = os.path.join(BASE, 'with_ranking', 'ranking_nfdr_metrics.csv')
    if os.path.exists(bl_path):
        df = pd.read_csv(bl_path)
        df_ctrl = df[df['condition'] == 'control'].copy()
        df_ctrl['condition'] = 'Baseline'
        df_exp  = df[df['condition'] == 'experimental'].copy()
        df_exp['condition'] = 'Raw_Memory'
        frames.extend([df_ctrl, df_exp])

    # Semantic RAG
    rag_path = os.path.join(BASE, 'with_rag', 'rag_nfdr_metrics.csv')
    if os.path.exists(rag_path):
        df = pd.read_csv(rag_path)
        df['condition'] = 'Semantic_RAG'
        frames.append(df)

    # Semantic RAG+
    ragp_path = os.path.join(BASE, 'with_rag_plus', 'rag_plus_nfdr_metrics.csv')
    if os.path.exists(ragp_path):
        df = pd.read_csv(ragp_path)
        df['condition'] = 'Semantic_RAG+'
        frames.append(df)

    # RAG+ with User Prompt — compute from run_log if dedicated NFDR CSV doesn't exist
    ragp_prompt_path = os.path.join(BASE, 'with_rag_plus_user_prompt', 'rag_plus_prompt_nfdr_metrics.csv')
    if os.path.exists(ragp_prompt_path):
        df = pd.read_csv(ragp_prompt_path)
        df['condition'] = 'RAG+_Prompt'
        frames.append(df)

    if frames:
        return pd.concat(frames, ignore_index=True)
    return pd.DataFrame()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 1: Grouped Bar — Mean Validated Pathway Count per Module
#            by Category × Condition, split Iter1 / Iter2
# ══════════════════════════════════════════════════════════════════════════

def plot_fig1_grouped_bar(pdata):
    """
    For each category: mean number of validated pathways per module,
    grouped by condition, with Iter1 and Iter2 shown as stacked.
    """
    fig, axes = plt.subplots(1, 5, figsize=(22, 5), sharey=False)
    fig.suptitle('Mean Validated Pathway Count per Module — by Category × Condition × Iteration',
                 fontsize=14, fontweight='bold', y=1.02)

    for ax, cat in zip(axes, CATS):
        sub = pdata[pdata['category'] == cat]
        if sub.empty:
            ax.set_title(cat)
            continue

        # Per (condition, module) → count by iteration
        iter1_counts = []
        iter2_counts = []
        for cond in CONDS:
            cs = sub[sub['condition'] == cond]
            if cs.empty:
                iter1_counts.append(0)
                iter2_counts.append(0)
                continue
            i1 = cs[cs['iteration'] == 1].groupby(['disease', 'module']).size()
            i2 = cs[cs['iteration'] == 2].groupby(['disease', 'module']).size()
            # Mean per module (including modules with 0) — use all modules present in condition
            all_modules = cs.groupby(['disease', 'module']).size().index
            i1_vals = i1.reindex(all_modules, fill_value=0)
            i2_vals = i2.reindex(all_modules, fill_value=0)
            iter1_counts.append(i1_vals.mean())
            iter2_counts.append(i2_vals.mean())

        x = np.arange(len(CONDS))
        w = 0.55
        bars1 = ax.bar(x, iter1_counts, w, label='Iter1 (retained)',
                       color=[COND_COLORS[c] for c in CONDS], alpha=0.9,
                       edgecolor='white', linewidth=0.5)
        bars2 = ax.bar(x, iter2_counts, w, bottom=iter1_counts,
                       label='Iter2 (new)',
                       color=[COND_COLORS[c] for c in CONDS], alpha=0.45,
                       edgecolor='white', linewidth=0.5,
                       hatch='///')

        # Add total value labels
        for i, (i1, i2) in enumerate(zip(iter1_counts, iter2_counts)):
            total = i1 + i2
            ax.text(i, total + 0.15, f'{total:.1f}', ha='center', va='bottom',
                    fontsize=8, fontweight='bold')
            # Add iter1 value inside bar
            if i1 > 0.3:
                ax.text(i, i1/2, f'{i1:.1f}', ha='center', va='center',
                        fontsize=7, color='white', fontweight='bold')

        ax.set_title(cat, fontsize=12, fontweight='bold', color=CAT_COLORS[cat])
        ax.set_xticks(x)
        ax.set_xticklabels([COND_LABELS.get(c, c) for c in CONDS], fontsize=8)
        ax.set_ylabel('Mean pathways / module' if ax == axes[0] else '')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    # Shared legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='grey', alpha=0.9, label='Iter1 (retained)'),
        Patch(facecolor='grey', alpha=0.45, hatch='///', label='Iter2 (new)'),
    ]
    fig.legend(handles=legend_elements, loc='upper right', fontsize=10,
               bbox_to_anchor=(0.98, 1.0))

    plt.tight_layout()
    path = os.path.join(OUT, 'memory_effect_fig1_pathway_count_by_category.png')
    fig.text(0.99, 0.01, '5 diseases | 69 modules', ha='right', va='bottom',
             fontsize=8, color='grey', alpha=0.7, style='italic')
    fig.savefig(path, dpi=200, bbox_inches='tight')
    print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 2: Heatmap — Paired Δ (Memory − Baseline) by Category × Iter
# ══════════════════════════════════════════════════════════════════════════

def plot_fig2_delta_heatmap(pdata):
    """
    For each (category, iteration), compute mean Δ = Memory − Baseline
    in validated pathway count per module. Show as heatmap.
    """
    memory_conds = [c for c in CONDS if c != 'Baseline']
    ncpanels = len(memory_conds)
    fig, axes = plt.subplots(1, ncpanels, figsize=(6.5 * ncpanels, 5.5), sharey=True)
    if ncpanels == 1:
        axes = [axes]
    fig.suptitle('Memory Bank Effect: Δ Validated Pathways vs Baseline (per module)\n'
                 'Positive = Memory found MORE pathways than Baseline',
                 fontsize=13, fontweight='bold', y=1.05)

    labels = [COND_LABELS.get(c, c) for c in memory_conds]

    for ax, mem_cond, label in zip(axes, memory_conds, labels):
        # Build matrix: rows = categories, cols = Iter1 | Iter2 | Total
        matrix = np.full((5, 3), np.nan)
        annot  = [[''] * 3 for _ in range(5)]

        for ci, cat in enumerate(CATS):
            sub = pdata[pdata['category'] == cat]
            for ji, iter_filter in enumerate([1, 2, None]):  # Iter1, Iter2, Total
                # Baseline per-module counts
                bl = sub[sub['condition'] == 'Baseline']
                mc = sub[sub['condition'] == mem_cond]
                if iter_filter is not None:
                    bl = bl[bl['iteration'] == iter_filter]
                    mc = mc[mc['iteration'] == iter_filter]

                if bl.empty and mc.empty:
                    continue

                # Per-module counts for paired comparison
                bl_per_mod = bl.groupby(['disease', 'module']).size()
                mc_per_mod = mc.groupby(['disease', 'module']).size()

                # Shared modules for paired comparison
                all_mods = bl_per_mod.index.union(mc_per_mod.index)
                bl_aligned = bl_per_mod.reindex(all_mods, fill_value=0)
                mc_aligned = mc_per_mod.reindex(all_mods, fill_value=0)

                deltas = mc_aligned - bl_aligned
                mean_delta = deltas.mean()
                matrix[ci, ji] = mean_delta

                # Significance test
                if len(deltas) > 5:
                    t, p = sp.wilcoxon(deltas[deltas != 0]) if (deltas != 0).sum() > 5 \
                           else (0, 1.0)
                    sig = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
                else:
                    sig = ''

                annot[ci][ji] = f'{mean_delta:+.2f}{sig}'

        # Plot heatmap
        im = ax.imshow(matrix, cmap='RdYlGn', aspect='auto',
                       vmin=-1.5, vmax=1.5)
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['Iter1', 'Iter2', 'Total'], fontsize=10)
        ax.set_yticks(range(5))
        ax.set_yticklabels(CATS, fontsize=10)
        ax.set_title(f'{label} − Baseline', fontsize=12, fontweight='bold',
                     color=COND_COLORS[mem_cond])

        # Annotate
        for ci in range(5):
            for ji in range(3):
                txt = annot[ci][ji]
                color = 'white' if abs(matrix[ci, ji]) > 1.0 else 'black'
                ax.text(ji, ci, txt, ha='center', va='center',
                        fontsize=10, fontweight='bold', color=color)

    # Colorbar — place in dedicated axis on the right
    fig.subplots_adjust(right=0.88)
    cbar_ax = fig.add_axes([0.90, 0.15, 0.015, 0.65])
    cbar = fig.colorbar(im, cax=cbar_ax)
    cbar.set_label('Δ pathways per module (Memory − Baseline)', fontsize=10)
    path = os.path.join(OUT, 'memory_effect_fig2_delta_heatmap.png')
    fig.text(0.99, 0.01, '5 diseases | 69 modules', ha='right', va='bottom',
             fontsize=8, color='grey', alpha=0.7, style='italic')
    fig.savefig(path, dpi=200, bbox_inches='tight')
    print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 3: Stacked bar — Iter1-retained + Iter2-new by Condition,
#            faceted by Category
# ══════════════════════════════════════════════════════════════════════════

def plot_fig3_iter_composition(pdata):
    """
    Show the composition of final TOP 5 pathways: how many come from Iter1 vs Iter2,
    and how that composition changes across conditions, for each category.
    Only pathways ranked in Top 5 (by gpt_rank) per module per category are counted.
    """
    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    fig.suptitle('Top 5 Pathway Composition: Iter1 Retained vs Iter2 New — by Category × Condition',
                 fontsize=14, fontweight='bold', y=1.01)

    # Flatten axes, last one for legend
    axs = axes.flatten()

    for idx, cat in enumerate(CATS):
        ax = axs[idx]
        sub = pdata[pdata['category'] == cat].copy()

        iter1_means = []
        iter2_means = []
        iter1_sems  = []
        iter2_sems  = []

        for cond in CONDS:
            cs = sub[sub['condition'] == cond].copy()
            if cs.empty:
                iter1_means.append(0)
                iter2_means.append(0)
                iter1_sems.append(0)
                iter2_sems.append(0)
                continue

            # Filter to Top 5 per module (by gpt_rank)
            top5 = cs.sort_values('gpt_rank').groupby(['disease', 'module']).head(5)

            # Per module
            i1_per = top5[top5['iteration'] == 1].groupby(['disease', 'module']).size()
            i2_per = top5[top5['iteration'] == 2].groupby(['disease', 'module']).size()
            all_mods = top5.groupby(['disease', 'module']).size().index
            i1 = i1_per.reindex(all_mods, fill_value=0)
            i2 = i2_per.reindex(all_mods, fill_value=0)

            iter1_means.append(i1.mean())
            iter2_means.append(i2.mean())
            iter1_sems.append(i1.sem())
            iter2_sems.append(i2.sem())

        x = np.arange(len(CONDS))
        w = 0.5

        # Iter1 bar
        bars1 = ax.bar(x, iter1_means, w,
                       color=CAT_COLORS[cat], alpha=0.9,
                       edgecolor='white', linewidth=0.8,
                       label='Iter1 retained')
        # Iter2 bar (stacked)
        bars2 = ax.bar(x, iter2_means, w, bottom=iter1_means,
                       color=CAT_COLORS[cat], alpha=0.4,
                       edgecolor='white', linewidth=0.8,
                       hatch='///', label='Iter2 new')

        # Error bars on total
        totals = [i1+i2 for i1, i2 in zip(iter1_means, iter2_means)]
        total_sems = [np.sqrt(s1**2 + s2**2) for s1, s2 in zip(iter1_sems, iter2_sems)]
        ax.errorbar(x, totals, yerr=total_sems, fmt='none', ecolor='black',
                    capsize=3, capthick=1, linewidth=1)

        # Labels
        for i in range(len(CONDS)):
            t = totals[i]
            ax.text(i, t + total_sems[i] + 0.1, f'{t:.1f}', ha='center', va='bottom',
                    fontsize=8, fontweight='bold')
            # Iter1 proportion
            if iter1_means[i] > 0:
                pct = iter1_means[i] / t * 100 if t > 0 else 0
                ax.text(i, iter1_means[i]/2, f'{pct:.0f}%',
                        ha='center', va='center', fontsize=7,
                        color='white', fontweight='bold')

        ax.set_title(cat, fontsize=12, fontweight='bold', color=CAT_COLORS[cat])
        ax.set_xticks(x)
        ax.set_xticklabels([COND_LABELS.get(c, c) for c in CONDS], fontsize=8)
        ax.set_ylabel('Mean Top 5 pathways / module')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    # Legend in last subplot
    axs[5].axis('off')
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='grey', alpha=0.85, label='Iter1 retained'),
        Patch(facecolor='grey', alpha=0.4, hatch='///', label='Iter2 new'),
    ]
    for cond in CONDS:
        legend_elements.append(
            Patch(facecolor=COND_COLORS[cond], label=COND_LABELS[cond]))
    axs[5].legend(handles=legend_elements, loc='center', fontsize=11,
                  frameon=True, fancybox=True, shadow=True)

    plt.tight_layout()
    path = os.path.join(OUT, 'memory_effect_fig3_iter_composition.png')
    fig.text(0.99, 0.01, '5 diseases | 69 modules', ha='right', va='bottom',
             fontsize=8, color='grey', alpha=0.7, style='italic')
    fig.savefig(path, dpi=200, bbox_inches='tight')
    print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 4: Positive Feedback Scatter — Iter1 count vs Final, by category
# ══════════════════════════════════════════════════════════════════════════

def plot_fig4_feedback_scatter(pdata):
    """
    Scatter plot: for each (disease, module, condition),
    x = Iter1 validated count in that category
    y = Total validated count in that category
    Colored by category, with regression lines per category.
    Sub-panels for each condition.
    """
    ncond = len(CONDS)
    ncols = 3
    nrows = (ncond + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(18, 6 * nrows))
    fig.suptitle('Positive Feedback Cycle: Iter1 Count → Final Total — by Category',
                 fontsize=14, fontweight='bold', y=1.01)
    axs = axes.flatten()
    # Hide unused subplots
    for i in range(ncond, len(axs)):
        axs[i].set_visible(False)

    for ax, cond in zip(axs[:ncond], CONDS):
        sub = pdata[pdata['condition'] == cond]

        all_r_texts = []
        for cat in CATS:
            cs = sub[sub['category'] == cat]
            if cs.empty:
                continue

            i1 = cs[cs['iteration'] == 1].groupby(['disease', 'module']).size()
            total = cs.groupby(['disease', 'module']).size()

            # Align
            all_mods = total.index
            i1_a = i1.reindex(all_mods, fill_value=0)

            # Scatter with jitter
            jitter = np.random.normal(0, 0.12, len(i1_a))
            ax.scatter(i1_a + jitter, total, s=18, alpha=0.5,
                      color=CAT_COLORS[cat], label=cat, edgecolors='none')

            # Regression line
            if len(i1_a) > 5:
                r, p = sp.spearmanr(i1_a, total)
                # Fit line
                z = np.polyfit(i1_a, total, 1)
                xline = np.linspace(0, i1_a.max() + 1, 50)
                ax.plot(xline, np.polyval(z, xline), '--',
                       color=CAT_COLORS[cat], alpha=0.7, linewidth=1.5)
                all_r_texts.append(f'{cat}: r={r:.2f}')

        # Diagonal
        lim = max(ax.get_xlim()[1], ax.get_ylim()[1])
        ax.plot([0, lim], [0, lim], 'k--', alpha=0.2, linewidth=0.8)

        ax.set_title(f'{COND_LABELS[cond]}', fontsize=12, fontweight='bold',
                     color=COND_COLORS[cond])
        ax.set_xlabel('Iter1 validated count')
        ax.set_ylabel('Total final count')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

        # r-value annotation box
        text_str = '\n'.join(all_r_texts)
        ax.text(0.02, 0.98, text_str, transform=ax.transAxes,
                fontsize=8, verticalalignment='top',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))

    # Shared legend
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=5, fontsize=10,
               bbox_to_anchor=(0.5, -0.02))

    plt.tight_layout()
    path = os.path.join(OUT, 'memory_effect_fig4_feedback_scatter.png')
    fig.text(0.99, 0.01, '5 diseases | 69 modules', ha='right', va='bottom',
             fontsize=8, color='grey', alpha=0.7, style='italic')
    fig.savefig(path, dpi=200, bbox_inches='tight')
    print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 5: Validation-rate comparison — by Category × Condition × Round
#            (to complement Figure 1's count view with rate view)
# ══════════════════════════════════════════════════════════════════════════

def hierarchical_module_bootstrap_mean_ci(frame, value_col='nfdr_pct',
                                          rng=None, n_boot=3000):
    """Mean and 95% CI using disease -> module clustered resampling.

    This matches the nfdr composite figure: disease is resampled first, then
    gene-list/module clusters are resampled within each selected disease.
    """
    if rng is None:
        rng = np.random.default_rng(2406)

    sub = frame[['disease', 'module', value_col]].copy()
    sub[value_col] = pd.to_numeric(sub[value_col], errors='coerce')
    sub = sub.dropna(subset=['disease', 'module', value_col])
    if sub.empty:
        return np.nan, np.nan, np.nan

    mean = float(sub[value_col].mean())
    disease_groups = []
    for _, disease_df in sub.groupby('disease', sort=False):
        module_groups = [
            g[value_col].to_numpy(dtype=float)
            for _, g in disease_df.groupby('module', sort=False)
            if len(g) > 0
        ]
        if module_groups:
            disease_groups.append(module_groups)

    if len(disease_groups) <= 1:
        return mean, mean, mean

    boot_means = np.empty(n_boot, dtype=float)
    n_diseases = len(disease_groups)
    for bi in range(n_boot):
        sampled_diseases = rng.integers(0, n_diseases, n_diseases)
        sampled_values = []
        for disease_idx in sampled_diseases:
            modules = disease_groups[disease_idx]
            sampled_modules = rng.integers(0, len(modules), len(modules))
            sampled_values.extend(modules[idx] for idx in sampled_modules)
        boot_means[bi] = np.mean(np.concatenate(sampled_values))

    ci_low, ci_high = np.percentile(boot_means, [2.5, 97.5])
    return mean, max(0.0, float(ci_low)), min(100.0, float(ci_high))


def plot_fig5_nfdr_rate_by_category(nfdr_data):
    """
    Compare Round 1 Baseline, memory-assisted Round 1 variants and Round 2 Baseline.
    This figure uses the same minimal style as the validation overview figures.
    """
    if nfdr_data.empty:
        print('  ⚠️  No NFDR data — skipping Figure 5')
        return

    from matplotlib.patches import Patch

    plt.rcParams.update({
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
        'pdf.fonttype': 42,
        'ps.fonttype': 42,
        'svg.fonttype': 'none',
        'axes.linewidth': 0.8,
        'axes.labelsize': 8,
        'xtick.labelsize': 6.9,
        'ytick.labelsize': 7.2,
    })

    GROUPS = [
        ('Baseline',      1, 'Round 1\nbaseline'),
        ('Raw_Memory',    1, 'Raw\nmemory'),
        ('Semantic_RAG',  1, 'Semantic\nRAG'),
        ('Semantic_RAG+', 1, 'RAG+'),
        ('RAG+_Prompt',   1, 'RAG+\nprompt'),
        ('Baseline',      2, 'Round 2\nbaseline'),
    ]
    GROUP_COLORS = ['#B8C5CC', '#8795D1', '#5CB8AF', '#E4B35A', '#D66A64', '#2F6F9F']
    GRID_COLOR = '#D9D9D9'

    fig, axes = plt.subplots(1, 5, figsize=(10.8, 3.95), sharey=True)
    fig.patch.set_facecolor('white')
    rng = np.random.default_rng(2406)

    for col, cat in enumerate(CATS):
        ax = axes[col]
        ax.set_facecolor('white')

        means, ci_lows, ci_highs = [], [], []
        for cond, iteration, _ in GROUPS:
            sub = nfdr_data[(nfdr_data['category'] == cat) &
                            (nfdr_data['iteration'] == iteration) &
                            (nfdr_data['condition'] == cond)].copy()
            # Per-iteration filtering: only modules with new_matched > 0
            if 'new_matched' in sub.columns:
                if iteration == 1:
                    sub = sub[sub['new_matched'] > 0]  # iter1: matched > 0 (= new_matched for iter1)
                else:
                    sub = sub[sub['new_matched'] > 0]  # iter2+: new_matched > 0
            if sub.empty:
                means.append(0); ci_lows.append(0); ci_highs.append(0)
            else:
                mean, ci_low, ci_high = hierarchical_module_bootstrap_mean_ci(
                    sub, 'nfdr_pct', rng=rng)
                means.append(mean)
                ci_lows.append(ci_low)
                ci_highs.append(ci_high)

        x = np.arange(len(GROUPS))
        w = 0.64
        means_arr = np.asarray(means, dtype=float)
        ci_lows_arr = np.asarray(ci_lows, dtype=float)
        ci_highs_arr = np.asarray(ci_highs, dtype=float)
        yerr = np.vstack([
            np.maximum(0.0, means_arr - ci_lows_arr),
            np.maximum(0.0, ci_highs_arr - means_arr),
        ])

        bars = ax.bar(
            x, means, w, yerr=yerr,
            color=GROUP_COLORS, edgecolor=GROUP_COLORS,
            linewidth=0.9, capsize=2.5,
            error_kw={'linewidth': 0.75, 'color': '#333333', 'capthick': 0.75},
            zorder=3
        )
        for bar in bars:
            bar.set_alpha(0.82)

        for i, (m, ci_high) in enumerate(zip(means, ci_highs)):
            if not np.isnan(m):
                ax.text(i, (m if np.isnan(ci_high) else ci_high) + 1.0, f'{m:.1f}',
                        ha='center', va='bottom', fontsize=6.6,
                        fontweight='bold', color='#222222')

        ax.set_title(cat, fontsize=9.2, fontweight='bold', pad=6)

        ax.set_xticks(x)
        ax.set_xticklabels([])
        if col == 0:
            ax.set_ylabel('Validation rate (%)')

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.tick_params(axis='both', colors='#222222', length=3, width=0.8)
        ax.grid(True, axis='y', alpha=0.8, linestyle='-', color=GRID_COLOR, linewidth=0.5)
        ax.set_axisbelow(True)
        ax.set_ylim(0, 60)
        ax.set_yticks(np.arange(0, 61, 15))
        ax.text(-0.22, 1.08, chr(ord('a') + col), transform=ax.transAxes,
                fontsize=10.5, fontweight='bold', ha='left', va='bottom')

    legend_elements = [
        Patch(facecolor=GROUP_COLORS[0], edgecolor=GROUP_COLORS[0], label='Round 1 baseline'),
        Patch(facecolor=GROUP_COLORS[1], edgecolor=GROUP_COLORS[1], label='Raw memory'),
        Patch(facecolor=GROUP_COLORS[2], edgecolor=GROUP_COLORS[2], label='Semantic RAG'),
        Patch(facecolor=GROUP_COLORS[3], edgecolor=GROUP_COLORS[3], label='RAG+'),
        Patch(facecolor=GROUP_COLORS[4], edgecolor=GROUP_COLORS[4], label='RAG+ prompt'),
        Patch(facecolor=GROUP_COLORS[5], edgecolor=GROUP_COLORS[5], label='Round 2 baseline'),
    ]
    fig.legend(handles=legend_elements, loc='upper center', bbox_to_anchor=(0.5, 0.91),
               ncol=6, fontsize=6.8, frameon=False, handlelength=1.2, columnspacing=1.1)

    fig.suptitle('Memory-assisted first-pass validation rate by category', x=0.5, y=1.02,
                 ha='center', fontsize=11.5, fontweight='bold')
    fig.subplots_adjust(left=0.065, right=0.99, top=0.78, bottom=0.12, wspace=0.2)

    for output_dir in [OUT, EXTERNAL_PDF_OUT]:
        for fmt in ['pdf', 'png', 'svg']:
            path = os.path.join(output_dir, f'memory_effect_fig5_nfdr_rate_by_category.{fmt}')
            fig.savefig(path, dpi=600 if fmt == 'png' else 300,
                        bbox_inches='tight', pad_inches=0.08, facecolor='white')
            print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  FIGURE 6: Amplification ratio bar — Iter2_new / Iter1_retained by cat
# ══════════════════════════════════════════════════════════════════════════

def plot_fig6_amplification(pdata):
    """
    Bar chart showing the amplification ratio (Iter2 new / Iter1 retained)
    for each category × condition.
    """
    fig, ax = plt.subplots(1, 1, figsize=(14, 6))
    fig.suptitle('Feedback Amplification Ratio: How Many Iter2 Pathways per Iter1 Anchor\n'
                 '(Iter2 new ÷ Iter1 retained, per category)',
                 fontsize=13, fontweight='bold', y=1.02)

    x = np.arange(len(CATS))
    n_conds = len(CONDS)
    w = 0.18

    for ci, cond in enumerate(CONDS):
        ratios = []
        for cat in CATS:
            sub = pdata[(pdata['category'] == cat) & (pdata['condition'] == cond)]
            i1 = sub[sub['iteration'] == 1].shape[0]
            i2 = sub[sub['iteration'] == 2].shape[0]
            ratio = i2 / i1 if i1 > 0 else 0
            ratios.append(ratio)

        offset = (ci - n_conds/2 + 0.5) * w
        bars = ax.bar(x + offset, ratios, w, label=COND_LABELS[cond],
                     color=COND_COLORS[cond], edgecolor='white', linewidth=0.5)

        for i, r in enumerate(ratios):
            ax.text(x[i] + offset, r + 0.03, f'{r:.2f}',
                    ha='center', va='bottom', fontsize=7, fontweight='bold')

    ax.axhline(y=1.0, color='black', linestyle='--', alpha=0.3, linewidth=1)
    ax.text(len(CATS)-0.5, 1.02, '1:1 ratio', fontsize=8, alpha=0.5)

    ax.set_xticks(x)
    ax.set_xticklabels(CATS, fontsize=11, fontweight='bold')
    ax.set_ylabel('Amplification ratio (Iter2 new / Iter1 retained)', fontsize=11)
    ax.legend(fontsize=10, loc='upper left')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    path = os.path.join(OUT, 'memory_effect_fig6_amplification_ratio.png')
    fig.text(0.99, 0.01, '5 diseases | 69 modules', ha='right', va='bottom',
             fontsize=8, color='grey', alpha=0.7, style='italic')
    fig.savefig(path, dpi=200, bbox_inches='tight')
    print(f'  ✅ Saved: {path}')
    plt.close()


# ══════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════

def main():
    print('Loading pathway data...')
    pdata = load_all_pathway_data()
    print(f'  Loaded {len(pdata)} pathway records')
    print(f'  Diseases: {sorted(pdata["disease"].unique())}')
    print(f'  Conditions: {sorted(pdata["condition"].unique())}')
    print(f'  Categories: {sorted(pdata["category"].unique())}')
    print()

    print('Loading NFDR data...')
    nfdr = load_nfdr_data()
    print(f'  Loaded {len(nfdr)} NFDR records')
    print()

    print('Generating Figure 1: Grouped bar — pathway counts by category...')
    plot_fig1_grouped_bar(pdata)

    print('Generating Figure 2: Delta heatmap — Memory vs Baseline...')
    plot_fig2_delta_heatmap(pdata)

    print('Generating Figure 3: Iteration composition by category...')
    plot_fig3_iter_composition(pdata)

    print('Generating Figure 4: Positive feedback scatter by category...')
    plot_fig4_feedback_scatter(pdata)

    print('Generating Figure 5: NFDR rate by category × iteration...')
    plot_fig5_nfdr_rate_by_category(nfdr)

    print('Generating Figure 6: Amplification ratio by category...')
    plot_fig6_amplification(pdata)

    print(f'\n✅ All figures saved to: {OUT}')


if __name__ == '__main__':
    main()
